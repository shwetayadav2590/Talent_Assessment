from flask import Flask, render_template, request, jsonify
import os
import random
from flask_mysqldb import MySQL


app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')


# MySQL configurations
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'Shweta9967013742'
app.config['MYSQL_DB'] = 'test2'

mysql = MySQL(app)

def generate_unique_file_name(upload_path, file_name_without_ext, extname, num=1):
    file_name = f"{file_name_without_ext}_{num}{extname}" if num > 1 else f"{file_name_without_ext}{extname}"
    file_path = os.path.join(upload_path, file_name)
    if os.path.exists(file_path):
        return generate_unique_file_name(upload_path, file_name_without_ext, extname, num + 1)
    return file_name

@app.route('/')
def login_page():
    return render_template('login_1.html')

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']

    # Your logic to check login credentials and get the role
        # Query to check if the provided username and password exist in the database
    query = 'SELECT role FROM users WHERE user_name = %s AND password = %s'
    try:
        cursor = mysql.connection.cursor()
        cursor.execute(query, (username, password))
        result = cursor.fetchone()

        if result:
            role = result[0]
            print(f"Login successful! Welcome, {username} (Role: {role})")

            if role != 'student':
                return render_template('index_fileupload.html')
            else:
                return render_template('student_mainmenu1.html')
        else:
            return "Invalid username or password."
    except Exception as e:
        print('Error executing query:', e)
        return "Error connecting to the database.", 500
    finally:
        cursor.close()

    role = 'admin'  # Replace this with your logic to get the role from the database
    print(f"Login successful! Welcome, {username} (Role: {role})")

    if role != 'student':
        return render_template('index_fileupload.html')
    else:
        return render_template('student_mainmenu1.html')

@app.route('/index_fileupload.html')
def index_fileupload_page():
    return render_template('index_fileupload.html')

@app.route('/upload', methods=['POST'])
def upload():
    file = request.files['file']
    if file:
        category = request.form['category']
        category_folder_path = os.path.join(app.config['UPLOAD_FOLDER'], category)

        if not os.path.exists(category_folder_path):
            os.makedirs(category_folder_path)

        original_name, extname = os.path.splitext(file.filename)
        file_name_without_ext = os.path.basename(original_name)
        unique_file_name = generate_unique_file_name(app.config['UPLOAD_FOLDER'], file_name_without_ext, extname)

        file.save(os.path.join(category_folder_path, unique_file_name))
        return f"File uploaded and saved as {unique_file_name} in category {category} successfully!"
    else:
        return "No file uploaded.", 400

@app.route('/registration.html')
def registration_page():
    return render_template('registration.html')

@app.route('/register', methods=['POST'])
def register():
    new_username = request.form['newUsername']
    new_password = request.form['newPassword']
    email_id = request.form['email_id']
    phone_no = request.form['phone_no']
    role = 'student'  # Set the role as "student"

    # Your logic to insert the new user into the database
    # Insert the new user into the database
    try:
        cursor = mysql.connection.cursor()
        addUserQuery = 'INSERT INTO users (user_name, password, role, email_id, phone_no) VALUES (%s, %s, %s, %s, %s)'
        cursor.execute(addUserQuery, (new_username, new_password, role, email_id, phone_no))
        mysql.connection.commit()
        cursor.close()
        return "User registered successfully!"
    except Exception as e:
        print('Error inserting user: ', e)
        return "Error connecting to the database.", 500


    return "User registered successfully!"
@app.route('/generate_exam', methods=['GET'])
def generate_exam():
    app.logger.info("generate_exam route called.")
    total_questions = int(request.args.get('totalQuestions'))
    selected_subject = request.args.get('subject')

    # Query to select random rows from the 'mcq' table based on the subject
    query = 'SELECT ques_id, questions, option_a, option_b, option_c, option_d, correct_ans FROM mcq WHERE sub_id IN (SELECT sub_id FROM subject WHERE sub_name = %s) ORDER BY RAND() LIMIT %s'
    try:
        cursor = mysql.connection.cursor()
        cursor.execute(query, (selected_subject, total_questions))
        result = cursor.fetchall()

        # Ensure that the query returned some questions
        if not result:
            return jsonify(error='No questions found for the selected subject.')

        # Process the result and format the questions and options
        questions = []
        for row in result:
            ques_id, question, option_a, option_b, option_c, option_d, correct_ans = row
            question_data = {
                'ques_id': ques_id,
                'question': question,
                'option_a': option_a,
                'option_b': option_b,
                'option_c': option_c,
                'option_d': option_d,
                'correct_ans': correct_ans,
            }
            questions.append(question_data)

        print('Generated Questions:', questions)  # Add this line for debugging
        return jsonify(questions)
    except mysql.connection.Error as e:
        print('Error executing query:', e)
        return jsonify(error='Error fetching data from the database'), 500
    finally:
        cursor.close()


@app.route('/student_mainmenu1.html')
def student_mainmenu_page():
    return render_template('student_mainmenu1.html')

@app.route('/student2_index.html')
def student2_index_page():
    return render_template('student2_index.html')
@app.route('/submission_complete.html')
def submission_complete_page():
    return render_template('submission_complete1.html')

@app.route('/assessment_report')
def assessment_report_page():
    return render_template('report.html')

if __name__ == '__main__':
    app.run(port=4005)
